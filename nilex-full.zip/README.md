# Nilex — Full Deployment Package

This repo is a production-ready scaffold for Nilex (Anchor program + frontend + backend + CI).
