use anchor_lang::prelude::*;

declare_id!("Nilex1111111111111111111111111111111111111");

#[program]
pub mod nilex {
    use super::*;

    pub fn initialize_pool(ctx: Context<InitializePool>, fee_bps: u16, base_rate: u64) -> Result<()> {
        let pool = &mut ctx.accounts.pool;
        pool.fee_bps = fee_bps;
        pool.base_rate = base_rate;
        pool.volume_24h = 0;
        pool.bump = *ctx.bumps.get("pool").unwrap_or(&0);
        Ok(())
    }

    pub fn swap(ctx: Context<Swap>, amount_in: u64) -> Result<()> {
        // Placeholder: implement token transfer + fee logic
        let pool = &mut ctx.accounts.pool;
        let fee = calculate_fee(amount_in, pool.volume_24h, pool.fee_bps)?;
        // apply swap logic (omitted here for safety)
        pool.volume_24h = pool.volume_24h.saturating_add(amount_in);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializePool<'info> {
    #[account(init, payer = payer, space = 8 + 64, seeds = [b"pool"], bump)]
    pub pool: Account<'info, Pool>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Swap<'info> {
    #[account(mut, seeds = [b"pool"], bump = pool.bump)]
    pub pool: Account<'info, Pool>,
    // token accounts and user signer would go here
}

#[account]
pub struct Pool {
    pub teos_mint: Pubkey,
    pub tut_mint: Pubkey,
    pub fee_wallet: Pubkey,
    pub fee_bps: u16,
    pub base_rate: u64,
    pub volume_24h: u64,
    pub bump: u8,
}

pub fn calculate_fee(amount: u64, volume_24h: u64, fee_bps_override: u16) -> Result<u64> {
    // dynamic fee logic based on volume_24h, fallback to fee_bps_override
    let fee_bps = if volume_24h > 1_000_000_000 {
        15u16
    } else if volume_24h > 100_000_000 {
        25u16
    } else {
        fee_bps_override
    };
    Ok(amount.checked_mul(fee_bps as u64).unwrap_or(0) / 10_000u64)
}
