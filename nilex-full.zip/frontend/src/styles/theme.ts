export const nilexTheme = {
  palette: {
    mode: 'dark',
    primary: { main: '#FFD700' },
    background: { default: '#000000' },
    text: { primary: '#FFFFFF' }
  }
};
