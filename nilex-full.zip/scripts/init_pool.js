// Node script stub to initialize pool via Anchor client (requires wallet + RPC)
console.log('Run with: node scripts/init_pool.js --rpc <RPC_URL> --wallet <PATH_TO_KEYPAIR>');
